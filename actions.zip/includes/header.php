<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title><?= htmlspecialchars($pageTitle) ?></title>
<link rel="manifest" href="/mknet/manifest.json">
<meta name="theme-color" content="#0f172a">
<link rel="icon" href="/mknet/assets/images/favicon.png">

<!-- Google Fonts -->
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Outfit:wght@300;400;500;600;700;800;900&family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet">

<!-- FontAwesome Icons & Swiper CSS & Chart.js -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper@10/swiper-bundle.min.css">
<script src="https://cdnjs.cloudflare.com/ajax/libs/three.js/r128/three.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/swiper@10/swiper-bundle.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

<link rel="stylesheet" href="/mknet/assets/style.css">

<script>
if ('serviceWorker' in navigator) {
  window.addEventListener('load', function() {
    navigator.serviceWorker.register('/mknet/sw.js').catch(function(err) {});
  });
}
</script>

<style>
:root {
  --primary-glow: #6366f1;
  --secondary-glow: #8b5cf6;
  --accent-cyan: #06b6d4;
  --accent-emerald: #10b981;
  --bg-dark: #090d16;
  --card-bg: rgba(15, 23, 42, 0.75);
  --border-glass: rgba(255, 255, 255, 0.12);
}

body {
  margin: 0;
  font-family: 'Plus Jakarta Sans', 'Outfit', sans-serif;
  background: var(--bg-dark);
  color: #f8fafc;
  overflow-x: hidden;
}

.site-header {
  background: rgba(9, 13, 22, 0.85);
  backdrop-filter: blur(16px);
  -webkit-backdrop-filter: blur(16px);
  border-bottom: 1px solid rgba(255, 255, 255, 0.08);
  padding: 14px 28px;
  position: sticky;
  top: 0;
  z-index: 1000;
  box-shadow: 0 4px 30px rgba(0, 0, 0, 0.4);
}

.site-header nav ul {
  list-style: none;
  display: flex;
  align-items: center;
  gap: 8px;
  padding: 0;
  margin: 0;
}

.site-header nav a {
  color: #cbd5e1;
  text-decoration: none;
  font-weight: 600;
  font-size: 0.95rem;
  padding: 8px 16px;
  border-radius: 10px;
  transition: all 0.25s cubic-bezier(0.4, 0, 0.2, 1);
  display: flex;
  align-items: center;
  gap: 8px;
}

.site-header nav a:hover {
  background: rgba(99, 102, 241, 0.15);
  color: #a5b4fc;
  transform: translateY(-1px);
}

.site-header nav a.active {
  background: linear-gradient(135deg, rgba(99, 102, 241, 0.25), rgba(139, 92, 246, 0.25));
  color: #818cf8;
  border: 1px solid rgba(99, 102, 241, 0.3);
}

.dropdown { position: relative; }
.dropdown-content {
  display: none;
  position: absolute;
  top: 100%;
  right: 0;
  background: rgba(15, 23, 42, 0.95);
  backdrop-filter: blur(16px);
  border: 1px solid rgba(255,255,255,0.12);
  border-radius: 14px;
  min-width: 220px;
  box-shadow: 0 15px 35px rgba(0,0,0,0.6);
  z-index: 1001;
  overflow: hidden;
  padding: 8px 0;
  animation: fadeInDown 0.25s ease-out forwards;
}

@keyframes fadeInDown {
  from { opacity: 0; transform: translateY(-8px); }
  to { opacity: 1; transform: translateY(0); }
}

.dropdown-content a {
  padding: 10px 18px;
  display: flex;
  align-items: center;
  gap: 10px;
  font-size: 0.9rem;
  color: #cbd5e1;
  border-radius: 0;
}
.dropdown-content a:hover {
  background: rgba(99, 102, 241, 0.2);
  color: #fff;
}
.dropdown:hover .dropdown-content, .dropdown.active .dropdown-content { display: block !important; }

.logo-brand {
  display: flex;
  align-items: center;
  gap: 12px;
  text-decoration: none;
  color: #fff;
  font-family: 'Outfit', sans-serif;
  font-size: 1.5rem;
  font-weight: 800;
  letter-spacing: -0.5px;
}
.logo-badge {
  background: linear-gradient(135deg, #6366f1, #8b5cf6);
  padding: 6px 12px;
  border-radius: 10px;
  box-shadow: 0 0 15px rgba(99,102,241,0.5);
  font-weight: 900;
}

.btn-header-glow {
  background: linear-gradient(135deg, #10b981, #059669);
  color: #fff !important;
  font-weight: 700 !important;
  padding: 8px 18px !important;
  border-radius: 10px !important;
  box-shadow: 0 4px 15px rgba(16,185,129,0.3);
}
.btn-header-glow:hover {
  box-shadow: 0 6px 20px rgba(16,185,129,0.5);
  transform: translateY(-2px) !important;
}

@media (max-width: 992px) {
  .header-container { flex-direction: column; gap: 16px; align-items: flex-start; }
  header nav ul { flex-wrap: wrap; gap: 8px; }
  header nav ul li a { padding: 8px 12px; font-size: 0.85rem; }
  html, body { max-width: 100vw; overflow-x: hidden !important; }
}
</style>
</head>
<body>

<?php
try {
    $activeBanner = $pdo->query(
        "SELECT * FROM admin_banners WHERE active=1 AND (starts_at IS NULL OR starts_at <= NOW()) AND (ends_at IS NULL OR ends_at >= NOW()) ORDER BY id DESC LIMIT 1"
    )->fetch();
    if ($activeBanner) {
        echo '<div style="background: linear-gradient(135deg, #6366f1, #8b5cf6); color:#fff; text-align:center; padding:10px 16px; font-weight:700; font-size:14px; letter-spacing:0.5px; box-shadow:0 2px 10px rgba(99,102,241,0.4);">';
        if (!empty($activeBanner['link_url'])) echo '<a href="' . h($activeBanner['link_url']) . '" style="color:#fff;text-decoration:underline;">';
        echo '✨ ' . h($activeBanner['message']);
        if (!empty($activeBanner['link_url'])) echo '</a>';
        echo '</div>';
    }
} catch (Throwable $e) {}
?>

<header class="site-header">
  <div style="display:flex; align-items:center; justify-content:space-between; max-width:1300px; margin:0 auto; flex-wrap:wrap; gap:16px;">
    <!-- Logo -->
    <a class="logo-brand" href="/mknet/">
      <span class="logo-badge">MK</span>
      <span>Net <span style="color:#818cf8; font-weight:400;">ISP</span></span>
    </a>

    <!-- Navigation -->
    <nav>
      <ul>
        <li><a href="/mknet/index.php"><i class="fa-solid fa-house"></i> Home</a></li>
        <li><a href="/mknet/pages/ai_experience.php" style="background: rgba(236,72,153,0.15); border: 1px solid rgba(236,72,153,0.4); color: #f472b6; font-weight: 800;"><i class="fa-solid fa-brain"></i> AI Experience Hub</a></li>
        <li><a href="/mknet/pages/packages.php"><i class="fa-solid fa-box-open"></i> Packages</a></li>
        <li><a href="/mknet/pages/paybill.php"><i class="fa-solid fa-credit-card"></i> Pay Bill</a></li>
        <li><a href="/mknet/pages/selfcare_login.php" class="btn-header-glow"><i class="fa-solid fa-user-gear"></i> Self Care Portal</a></li>
        <li><a href="/mknet/pages/coverage.php"><i class="fa-solid fa-network-wired"></i> Coverage</a></li>
        <li><a href="/mknet/pages/about.php"><i class="fa-solid fa-circle-info"></i> About</a></li>
        <li><a href="/mknet/pages/contact.php"><i class="fa-solid fa-headset"></i> Contact</a></li>

        <!-- Services Dropdown -->
        <li class="dropdown">
          <a href="javascript:void(0)" onclick="this.parentNode.classList.toggle('active')"><i class="fa-solid fa-bars"></i> More <i class="fa-solid fa-chevron-down" style="font-size:0.75rem;"></i></a>
          <div class="dropdown-content">
            <a href="/mknet/pages/appointment.php"><i class="fa-solid fa-calendar-check" style="color:#38bdf8;"></i> Book Appointment</a>
            <a href="/mknet/pages/network_status.php"><i class="fa-solid fa-signal" style="color:#10b981;"></i> Network Status</a>
            <a href="/mknet/pages/community.php"><i class="fa-solid fa-users"></i> Community</a>
            <a href="/mknet/pages/reviews.php"><i class="fa-solid fa-star" style="color:#f59e0b;"></i> Customer Reviews</a>
            <a href="/mknet/pages/news.php"><i class="fa-solid fa-newspaper"></i> Latest News</a>
            <a href="/mknet/pages/speedtest.php"><i class="fa-solid fa-gauge-high"></i> Speed Test</a>
            <a href="javascript:void(0)" onclick="if(window.mknetOpenAssistant) window.mknetOpenAssistant();"><i class="fa-solid fa-microphone" style="color:#ec4899;"></i> Voice Assistant</a>
            <hr style="border:0; border-top:1px solid rgba(255,255,255,0.08); margin:4px 0;">
            <a href="/mknet/admin/login.php" style="color:#818cf8; font-weight:700;"><i class="fa-solid fa-shield-halved"></i> Admin Login</a>
          </div>
        </li>
      </ul>
    </nav>
  </div>
</header>

<main class="container" style="min-height: 80vh;">

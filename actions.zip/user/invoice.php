<?php
require_once __DIR__ . '/../config.php';
session_start();
if(!isset($_SESSION['user_id'])){
  header("Location: login.php");
  exit;
}

$id = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT);
if (!$id) { die("Invalid invoice."); }
$stmt = $pdo->prepare("SELECT b.*, u.email FROM billing b JOIN users u ON b.user_id=u.id WHERE b.id=? AND b.user_id=?");
$stmt->execute([$id, $_SESSION['user_id']]);
$bill = $stmt->fetch();

if(!$bill){ die("Invoice not found."); }
?>
<link rel="stylesheet" href="../admin/style.css">

<div class="main">
  <h2>Invoice #<?= h($bill['id']) ?></h2>
  <p>User: <?= h($bill['email']) ?></p>
  <p>Amount: <?= h($bill['amount']) ?> BDT</p>
  <p>Status: <?= h($bill['status']) ?></p>
  <p>Due Date: <?= h($bill['due_date']) ?></p>
  <p>Paid Date: <?= h($bill['paid_date']) ?></p>
  <p>Transaction ID: <?= h($bill['transaction_id'] ?? 'N/A') ?></p>
</div>

<?php $pageTitle='Client Reviews'; require __DIR__.'/../config.php'; include __DIR__.'/../includes/header.php';
$rows=$pdo->query("SELECT * FROM reviews ORDER BY created_at DESC")->fetchAll(); ?>
<h2>Client reviews</h2>
<div class="grid">
<?php foreach($rows as $r): ?>
  <div class="card">
    <?php $avatar = "/mknet/assets/images/avatars/".strtolower(explode(" ", $r['user_name'])[0]).".jpg"; ?>
<img src="<?=$avatar?>" alt="<?=h($r['user_name'])?>" style="width:64px;height:64px;border-radius:50%;object-fit:cover;margin-bottom:8px">
    <h3><?=h($r['user_name'])?></h3>
    <p><b>Rating:</b> <?=h($r['rating'])?>/5</p>
    <p><?=h($r['comment'])?></p>
    <p class="tiny"><?=h($r['created_at'])?></p>
  </div>
<?php endforeach; ?>
</div>
<?php include __DIR__.'/../includes/footer.php'; ?>
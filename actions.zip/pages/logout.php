<?php
require_once __DIR__ . '/../config.php';
if (session_status() === PHP_SESSION_NONE) session_start();
SessionManager::destroyCurrent($pdo);
header("Location: login.php");
exit;

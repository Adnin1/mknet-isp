<?php
require_once __DIR__ . '/../config.php';
session_start();
if(!isset($_SESSION['user_id'])){http_response_code(403);exit;}

$data = json_decode(file_get_contents("php://input"), true);
$theme = $data['theme'];

$stmt = $pdo->prepare("UPDATE users SET theme_preference=? WHERE id=?");
$stmt->execute([$theme, $_SESSION['user_id']]);

$_SESSION['theme'] = $theme;
echo json_encode(['status'=>'ok']);
?>

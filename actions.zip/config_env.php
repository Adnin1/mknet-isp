<?php
use Dotenv\Dotenv;

require_once __DIR__ . '/vendor/autoload.php';

$dotenv = Dotenv::createImmutable(__DIR__);
$dotenv->load();

// Now you can access credentials like:
$bkashKey = $_ENV['BKASH_APP_KEY'];
$nagadMerchant = $_ENV['NAGAD_MERCHANT_ID'];
